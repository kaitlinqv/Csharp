﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermSE310_1
{
    class Employee
    {
        //declarations and private variables
        private string name;
        private int years;
        private double hourlyWage;

        //full constructor
        public Employee(string n, int y, double w)
        {
            name = n;
            years = y;
            hourlyWage = w;
        }

        //properties get & set
        public string Name
        {
            get
            {
                return name;
            }  //end get
            set
            {
                name = value;
            }  //end set
        }  //end name get and set

        public int Years  //years property
        {
            get
            {
                return years;
            }  //end get
            set  //set with range check
            {
                if (value >= 0 && value <= 55)
                    years = value;
                else
                    throw new ArgumentOutOfRangeException("Years", value, "Years must be between 0-55!");
            }  //end set
        }  //end years get and set

        public double HourlyWage  //hourlyWage property
        {
            get 
            {
                return hourlyWage;
            }  //end getter
            set  //set with range check
            {
                if (value > 0)
                    hourlyWage = value;
                else
                    throw new ArgumentOutOfRangeException("Hourly Wage", value, "Hourly Wage must be above 0!");
            }  //end setter
        }  //end Hourly Wage property

        public void display()  //display method
        {
            Console.WriteLine("\nName\t\tYrs Employed\t\tHourly Wage");
            Console.WriteLine("{0}\t\t{1}\t\t\t{2}\n", name, years, hourlyWage);
        }  //end display method
    }
}
