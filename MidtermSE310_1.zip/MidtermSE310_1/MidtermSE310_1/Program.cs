﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermSE310_1
{
    class Program
    {
        static void Main(string[] args)  //main method
        {
            //declarations
            string name = "";
            int years = 0;
            double hourlyWage = 0;

            Console.WriteLine("Please enter employee name:");
            name = Console.ReadLine();
            do  //do while for years
            {
                Console.WriteLine("Please enter years employed(0-55):");
                years = Convert.ToInt32(Console.ReadLine());
            }while(years<0||years>55);
            do  //do while for hourlyWage
            {
                Console.WriteLine("Please enter employee hourly wage:");
                hourlyWage = Convert.ToDouble(Console.ReadLine());
            } while (hourlyWage < 0);  //while hourlyWage is less than 0

            //new display using class
            Employee newE = new Employee(name, years, hourlyWage);
            newE.display();
            //display inputs
            //Console.WriteLine("\nName\t\tYrs Employed\t\tHourly Wage");
            //Console.WriteLine("{0}\t\t{1}\t\t\t{2}\n", name, years, hourlyWage);

            Console.Read();  //catchall

        }  //end main
    }
}
