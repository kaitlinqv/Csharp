﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidtermSE310_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            MessageBox.Show(txtMessage.Text);  //show the message!
            lstMessages.Items.Add(txtMessage.Text);  //add to list box
        }

        private void txtMessage_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();  //close the forum!
        }

        private void chkDisable_CheckedChanged(object sender, EventArgs e)
        {
            if (chkDisable.Checked == true)  //check if checked!
            {
                //toggle buttons disabled
                btnDisplay.Enabled = false;
                btnClose.Enabled = false;
            }
            else  //re-enable those bitches!
            {
                btnDisplay.Enabled = true;
                btnClose.Enabled = true;
            }
        }
    }
}
