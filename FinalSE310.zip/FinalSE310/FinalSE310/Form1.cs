﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalSE310
{
    public partial class Form1 : Form
    {
        private ArrayList Comics;  //declare private variables
        private int currComic;
        private StreamWriter fileWriter;

        public Form1()
        {
            InitializeComponent();
            Comics = new ArrayList();
            currComic = 0;
            
        }
        private void UpdateComic()  //update comic
        {
            //load variables from the screen to the ArrayList
            ((Comic)Comics[currComic]).Issue = Convert.ToInt32(issueBox.Text);
            ((Comic)Comics[currComic]).Title = titleBox.Text;
            ((Comic)Comics[currComic]).Price = Convert.ToDouble(priceBox.Text);
            ((Comic)Comics[currComic]).InCollection = icCkBox.Checked;
        }  //end UpdateComic

        private void DisplayComic() //display comic
        {
            //show comics in array list on screen
            issueBox.Text = Convert.ToString(((Comic)Comics[currComic]).Issue);
            titleBox.Text = ((Comic)Comics[currComic]).Title;
            priceBox.Text = Convert.ToString(((Comic)Comics[currComic]).Price);
            icCkBox.Checked = ((Comic)Comics[currComic]).InCollection;
        }  //end displayComic

        private void SaveComic(string fileName)  //save file method
        {
            UpdateComic();  //update fruit
            FileStream output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);

            fileWriter = new StreamWriter(output);  //create fileWriter
            foreach (Comic book in Comics)  //for each fruit
            {
                //write tha fruit
                fileWriter.WriteLine(Convert.ToString(book.Issue) + "," + book.Title + "," + Convert.ToString(book.Price) + ","
                    + Convert.ToString(book.InCollection));
            }
            fileWriter.Close();  //close file writer

        }  //end saveFruitBasket
        #region Buttons
        private void addBtn_Click(object sender, EventArgs e)  //add button
        {
            if(issueBox.Text != "")  //if not empty, update
            {
                UpdateComic();
            }
            foreach (Control ctrl in Controls)  //enable everything
            {
                ctrl.Enabled = true;
            }  //end foreach
           // if (currComic > null)
                currComic = Comics.Count;
            Comic newComic = new Comic();  //new comic
            newComic.Issue = currComic;  //indexing
            Comics.Add(newComic);  //add comic
            DisplayComic();

        }  //end add btn

        private void nextBtn_Click(object sender, EventArgs e)  //next button
        {
            UpdateComic();  //update
            if (currComic < Comics.Count-1)
            {
                currComic++;  //incriment
                DisplayComic();  //display
               
            }else
            {
                MessageBox.Show("There is no Next Comic Book!", "ERROR", MessageBoxButtons.OK);
            }  //end if
            
        }  //end next button

        private void prevBtn_Click(object sender, EventArgs e)  //previous button
        {
            UpdateComic();  //update
            if (currComic > 0)
            {
                currComic--;  //minus
                DisplayComic();  //display
            }  //end if
        }  //end previous button

        private void closeBtn_Click(object sender, EventArgs e)  //close button
        {
            this.Close();
        }
        #endregion

        private void saveBtn_Click(object sender, EventArgs e)   //save button
        {
            DialogResult result;  //result
            string fileName;

            using (SaveFileDialog fileChooser = new SaveFileDialog())  //using chooser
            {
                fileChooser.CheckFileExists = false;
                result = fileChooser.ShowDialog();
                fileName = fileChooser.FileName;
            }

            if (result == DialogResult.OK) //if result is OK
            {
                if (fileName == string.Empty)
                    MessageBox.Show("Invalid File Name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    try
                    {
                        SaveComic(fileName);
                        //FileStream output = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write);

                        //fileWriter = new StreamWriter(output);

                        //saveBtn.Enabled = false;
                        //enterBtn.Enabled = true;
                    }//end try
                    catch (IOException)
                    {
                        MessageBox.Show("Error opening file", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    } ///end catch
                }  //end else
            }  //end if
        }
    }
}
