﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalSE310
{
    class Comic
    {
        //declarations
        private int issue;
        private string title;
        private double price;
        private bool inCollection;

        //constructor
        public Comic()  //base constructor
        {
            issue = 0;
            title = "";
            price = 0;
            inCollection = false;
        }  //end base constructor

        public Comic(int i, string t, double p, bool iC)  //full constructor
        {
            issue = i;
            title = t;
            price = p;
            inCollection = iC;
        }  //end full constructor

        //setters and getters
        public int Issue  //issue getter & setter
        {
            get
            {
                return issue;
            }
            set
            {
                issue = value;
            }
        }  //end issue get & set

        public string Title  //title get & set
        {
            get
            {
                return title;
            }
            set
            {
                title = value;
            }
        }  //end title get & set

        public double Price  //price get & set
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }  //end price get & set

        public bool InCollection  //inCollection get & set
        {
            get
            {
                return inCollection;
            }
            set
            {
                inCollection = value;
            }
        }  //end inCollection get & set
    
    }
}
