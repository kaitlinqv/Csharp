﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            //declarations
            double num1 = 0;
            double num2 = 0;
            int option = 0;
            string name = "";
            int cont = 0;
            do
            {
                cont = 0;
                //prompts
                Console.WriteLine("Please enter your name");
                name = Console.ReadLine();
                Console.WriteLine("Please enter a number");
                num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Please enter a second number");
                num2 = Convert.ToDouble(Console.ReadLine());
                //check for bad inputs
                do
                {
                    Console.WriteLine("Please enter option option # (0-3)\n0 - sum\n1 - difference\n2 - product\n3 - quotient");
                    option = Convert.ToInt32(Console.ReadLine());
                } while (option < 0 || option > 3);

                //repeat name and numbers
                Console.WriteLine("Thanks {0}!\tThe numbers you entered are {1} and {2}\n", name, num1, num2);
                switch (option)
                {
                    case 0:
                        Console.WriteLine("The sum of your numbers is {0}", getSum(num1, num2));
                        break;
                    case 1:
                        Console.WriteLine("The difference of your numbers is {0}", getDifference(num1, num2));
                        break;
                    case 2:
                        Console.WriteLine("The product of your numbers is {0}", getProduct(num1, num2));
                        break;
                    case 3:
                        Console.WriteLine("The quotient of your numbers is {0}", getQuotient(num1, num2));
                        break;
                }
                do
                {
                    Console.WriteLine("Would you like to play again? (0-NO/QUIT 1-YES)");
                    cont = Convert.ToInt32(Console.ReadLine());
                } while (cont > 1 || cont < 0);  //play again entry check
            } while (cont == 1);  //play again while loop
        }

        static double getSum(double x, double y)  //sum function
        {
            return x + y;
        }
        
        static double getDifference(double x, double y)  //subtraction function
        {
            if (x > y)   //just cuz
                return x - y;
            else
                return y - x;
        }

        static double getProduct(double x, double y)  //product function
        {
            return x * y;
        }

        static double getQuotient(double x, double y)  //division function
        {
            if (x > y)  //just cuz
                return x / y;
            else
                return y / x;
        }
        
    }
}
